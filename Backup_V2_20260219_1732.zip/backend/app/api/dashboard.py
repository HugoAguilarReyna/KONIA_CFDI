from fastapi import APIRouter, Depends, HTTPException, Query, Request
from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from ..core.auth import decode_token
from ..core.database import get_database
from datetime import datetime
import re

router = APIRouter()

# --- Dependency ---
async def get_current_user_and_company(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        # Fallback for Dev/Swagger
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
             token = auth_header.replace("Bearer ", "")
        else:
             raise HTTPException(status_code=401, detail="Not authenticated")
    else:
        token = token.replace("Bearer ", "")
        
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
        
    # Ensure company_id is present (it should be int from auth.py mapping)
    company_id = payload.get("company_id")
    if company_id is None:
         raise HTTPException(status_code=403, detail="Company ID missing in token")
         
    return payload

# --- Endpoints ---

@router.get("/matriz-resumen")
async def get_matriz_resumen(
    periodo: str = Query(..., description="Format YYYY-MM"),
    user: dict = Depends(get_current_user_and_company)
):
    db = get_database()
    # Switch to fiscal_reports database
    fiscal_db = db.client["fiscal_reports"]
    
    company_id = user["company_id"]
    
    # 1. Fetch Data
    cursor = fiscal_db["matriz_resumen"].find({
        "company_id": company_id,
        "periodo": periodo
    })
    docs = list(cursor)
    
    # 2. Process Data into Nested Structure
    # matriz[segmento][concepto] = monto
    matriz = {"PPD": {}, "PUE": {}}
    
    for doc in docs:
        seg = doc.get("segmento")
        con = doc.get("concepto")
        if seg in matriz:
            matriz[seg][con] = float(doc.get("monto", 0.0))

    # 3. Calculate Fiscal KPIs (Strict Logic)
    
    # Helpers
    def get_val(seg, con):
        return matriz.get(seg, {}).get(con, 0.0)

    # Base Values
    total_facturado_ppd = get_val("PPD", "1. (+) Total Facturado")
    total_facturado_pue = get_val("PUE", "1. (+) Total Facturado")
    
    saldo_insoluto_ppd = get_val("PPD", "9. (=) Saldo Insoluto PPD")
    saldo_teorico_pue  = get_val("PUE", "9. (=) Saldo Teórico PUE")
    
    notas_credito_ppd = get_val("PPD", "2. (-) Notas de Crédito (01)")
    notas_credito_pue = get_val("PUE", "2. (-) Notas de Crédito (01)")

    # KPI Formulas
    # INGRESOS: (PUE + PPD) -> Actually user said "Ingresos Totales" is sum of Total Facturado both.
    # User: "INGRESOS TOTALES: matriz['PPD']['Total Facturado'] + matriz['PUE']['Total Facturado']"
    ingresos_totales = total_facturado_ppd + total_facturado_pue
    
    # RATIO PPD/PUE: Saldo Insoluto PPD / Total Facturado PUE
    if total_facturado_pue != 0:
        ratio_ppd_pue = (saldo_insoluto_ppd / total_facturado_pue) * 100
    else:
        ratio_ppd_pue = 0.0
        
    # STATUS FISCAL: 
    # Risk = Saldo Insoluto PPD / Total Facturado PPD
    # If Total Facturado PPD > 0, else 0
    if total_facturado_ppd > 0:
        pct_riesgo = abs(saldo_insoluto_ppd) / total_facturado_ppd * 100
    else:
        pct_riesgo = 0.0
        
    if pct_riesgo < 1.5:
        status = "SALUDABLE"
    elif pct_riesgo < 5.0:
        status = "EN OBSERVACIÓN"
    else:
        status = "EN RIESGO"

    return {
        "kpis": {
            "ingresos_totales": ingresos_totales,
            "saldo_ppd": saldo_insoluto_ppd,
            "ingreso_pue": total_facturado_pue, # User asked for "INGRESO PUE" based on Total Facturado PUE
            "creditos_nc": notas_credito_ppd + notas_credito_pue,
            "ratio_ppd_pue": ratio_ppd_pue,
            "status": status
        },
        "matriz": matriz, # Nested structure for frontend to parse
        "total_general": saldo_insoluto_ppd + saldo_teorico_pue,
        "subtotal_ppd": saldo_insoluto_ppd,
        "subtotal_pue": saldo_teorico_pue
    }

@router.get("/matriz-resumen/grafica-evolucion")
async def get_grafica_evolucion(
    periodos_count: int = Query(5, alias="periodos", description="Number of periods back"),
    user: dict = Depends(get_current_user_and_company)
):
    db = get_database()
    fiscal_db = db.client["fiscal_reports"]
    company_id = user["company_id"]
    
    # 1. Get distinct periods for this company
    all_periodos = fiscal_db["matriz_resumen"].distinct("periodo", {"company_id": company_id})
    all_periodos.sort() # Cronological order
    
    # Take last N
    target_periodos = all_periodos[-(periodos_count):]
    
    evolucion = []
    
    for p in target_periodos:
        # Find concepts for this period
        cursor = fiscal_db["matriz_resumen"].find({
            "company_id": company_id,
            "periodo": p,
            "concepto": {"$in": ["9. (=) Saldo Insoluto PPD", "9. (=) Saldo Teórico PUE"]}
        })
        docs = list(cursor)
        
        saldo_ppd = 0.0
        saldo_pue = 0.0
        
        for doc in docs:
            if doc["segmento"] == "PPD":
                saldo_ppd = float(doc.get("monto", 0.0))
            elif doc["segmento"] == "PUE":
                saldo_pue = float(doc.get("monto", 0.0))
                
        evolucion.append({
            "periodo": p,
            "saldo_ppd": saldo_ppd,
            "saldo_pue": saldo_pue
        })
        
    return evolucion


@router.get("/detalle-uuid")
async def get_detalle_uuid(
    periodo: str = Query(...),
    page: int = 1,
    limit: int = 25,
    flujo: Optional[str] = None,
    segmento: Optional[str] = None,
    user: dict = Depends(get_current_user_and_company)
):
    db = get_database()
    fiscal_db = db.client["fiscal_reports"]
    
    company_id = user["company_id"]
    
    # Base query
    query = {
        "company_id": company_id,
        "periodo": periodo
    }
    if flujo and flujo != "TODOS":
        query["flujo"] = flujo
    if segmento and segmento != "TODOS":
        query["segmento"] = segmento
        
    # Execution: Data Paged
    skip = (page - 1) * limit
    cursor = fiscal_db["detalle_uuid"].find(query).sort("saldo_acumulado", -1).skip(skip).limit(limit)
    items = list(cursor)
    for item in items:
        item["_id"] = str(item["_id"])

    # Execution: KPIs (Aggregation)
    # We need: Count, Sum(saldo_acumulado), Avg(saldo_acumulado), Ratio Emit/Recib
    # Note: Ratio Emit/Recib requires 'flujo' counts. If 'flujo' filter is active, ratio might be 100% or 0% or undefined.
    # The prompt implies KPIs for the "View", so usually respecting filters.
    # However, Ratio Emit/Recib implies a comparison, which might require ignoring the 'flujo' filter for that specific KPI?
    # Let's assume KPIs respect the current filters for now, except maybe Ratio if filters define context.
    # Actually, usually "Ratio I/E" is meaningful global or within the period.
    # Let's calculate KPIs based on the *current filter context*.
    
    pipeline = [
        {"$match": query},
        {"$group": {
            "_id": None,
            "total_count": {"$sum": 1},
            "total_saldo": {"$sum": "$saldo_acumulado"},
            "avg_saldo": {"$avg": "$saldo_acumulado"},
            "count_emitidos": {"$sum": {"$cond": [{"$eq": ["$flujo", "EMITIDOS"]}, 1, 0]}},
            "count_recibidos": {"$sum": {"$cond": [{"$eq": ["$flujo", "RECIBIDOS"]}, 1, 0]}}
        }}
    ]
    
    kpis_result = list(fiscal_db["detalle_uuid"].aggregate(pipeline))
    kpis = {
        "total_uuids": 0,
        "saldo_total": 0.0,
        "promedio_saldo": 0.0,
        "ratio_emit_recib": 0.0
    }
    
    if kpis_result:
        res = kpis_result[0]
        kpis["total_uuids"] = res["total_count"]
        kpis["saldo_total"] = res["total_saldo"]
        kpis["promedio_saldo"] = res["avg_saldo"]
        c_emit = res["count_emitidos"]
        c_recib = res["count_recibidos"]
        if c_recib > 0:
            kpis["ratio_emit_recib"] = (c_emit / c_recib) * 100
        else:
            kpis["ratio_emit_recib"] = c_emit * 100 # Or generic infinity handling
            
    return {
        "data": items,
        "kpis": kpis,
        "page": page,
        "limit": limit,
        "total_pages": (kpis["total_uuids"] + limit - 1) // limit
    }

@router.get("/trazabilidad")
async def get_trazabilidad(
    fecha_desde: Optional[str] = None,
    fecha_hasta: Optional[str] = None,
    user: dict = Depends(get_current_user_and_company)
):
    db = get_database()
    fiscal_db = db.client["fiscal_reports"]
    
    company_id = user["company_id"]
    
    query = {"company_id": company_id}
    
    # Simplistic period range query if provided
    if fecha_desde and fecha_hasta:
        query["periodo"] = {"$gte": fecha_desde, "$lte": fecha_hasta}
        
    cursor = fiscal_db["trazabilidad_uuid"].find(query).sort("fecha", 1).limit(500) # Soft limit for safety
    items = list(cursor)
    
    # KPIs calculation
    total_monto = sum(float(i.get("monto", 0)) for i in items)
    
    for item in items:
        item["_id"] = str(item["_id"])
            
    return {
        "data": items,
        "kpis": {
            "total_eventos": len(items),
            "saldo_total": total_monto,
            "primer_evento": items[0]["fecha"] if items else None,
            "ultimo_evento": items[-1]["fecha"] if items else None
        }
    }

@router.get("/trazabilidad/{uuid_raiz}")
async def get_trazabilidad_uuid(
    uuid_raiz: str,
    user: dict = Depends(get_current_user_and_company)
):
    db = get_database()
    fiscal_db = db.client["fiscal_reports"]
    
    company_id = user["company_id"]
    
    query = {
        "company_id": company_id,
        "uuid_raiz": uuid_raiz
    }
    
    cursor = fiscal_db["trazabilidad_uuid"].find(query).sort("fecha", 1)
    items = list(cursor)
    
    for item in items:
        item["_id"] = str(item["_id"])
        
    return {
        "data": items,
        "uuid_raiz": uuid_raiz
    }

@router.get("/dim-tiempo/{periodo}")
async def get_dim_tiempo(
    periodo: str,
    user: dict = Depends(get_current_user_and_company)
):
    db = get_database()
    fiscal_db = db.client["fiscal_reports"]
    
    doc = fiscal_db["dim_tiempo"].find_one({"periodo": periodo}, {"_id": 0})
    if not doc:
        # Return fallback if not found
        return {"periodo": periodo, "nombre_mes_es": periodo}
    return doc

@router.get("/riesgos/{uuid}")
async def get_risk_analysis(
    uuid: str,
    # Risk service likely uses 'cfdi_db' so standard get_database is fine inside wrapper
    current_user: dict = Depends(get_current_user_and_company) 
):
    from ..services.risk_wrapper import RiskService
    service = RiskService()
    data = service.analyze_invoice_risk(uuid)
    if "error" in data:
         if data["error"] == "Invoice not found":
             raise HTTPException(status_code=404, detail="Invoice not found")
         else:
             raise HTTPException(status_code=500, detail=data["error"])
    return data
