import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';
import clsx from 'clsx';

const KPICard = ({ title, value, icon: Icon, trend, trendValue, isLoading = false, color = "primary", variant = "glass" }) => {

    if (isLoading) {
        return (
            <div className={clsx("p-6 h-32 flex flex-col justify-between animate-pulse rounded-xl", variant === 'simple' ? "bg-white border border-slate-200 shadow-sm" : "glass-card")}>
                <div className="flex justify-between items-start">
                    <div className="h-4 bg-slate-200 rounded w-1/2"></div>
                    <div className="h-8 w-8 bg-slate-200 rounded-lg"></div>
                </div>
                <div className="space-y-2">
                    <div className="h-8 bg-slate-200 rounded w-3/4"></div>
                    <div className="h-3 bg-slate-200 rounded w-1/4"></div>
                </div>
            </div>
        );
    }

    const trendColors = {
        positive: 'text-success bg-success/10',
        negative: 'text-danger bg-danger/10',
        neutral: 'text-slate-500 bg-slate-100'
    };

    const trendIcon = {
        positive: <ArrowUpRight size={16} />,
        negative: <ArrowDownRight size={16} />,
        neutral: <Minus size={16} />
    };

    const cardStyles = variant === 'simple'
        ? "bg-white border border-slate-200 shadow-sm hover:shadow-md"
        : "glass-card hover:shadow-lg";

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className={clsx("p-6 relative overflow-hidden group transition-all duration-300 rounded-xl", cardStyles)}
        >
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500">
                {Icon && <Icon size={64} className={`text-${color}-500`} />}
            </div>

            <div className="flex justify-between items-start mb-4 relative z-10">
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider">{title}</h3>
                <div className={clsx("p-2 rounded-lg", `bg-${color}-50 text-${color}-600`)}>
                    {Icon && <Icon size={20} />}
                </div>
            </div>

            <div className="relative z-10">
                <div className="text-2xl font-bold text-slate-800 tracking-tight">
                    {value}
                </div>

                {trend && (
                    <div className={clsx("flex items-center gap-1 mt-2 text-xs font-medium w-fit px-2 py-1 rounded-full", trendColors[trend])}>
                        {trendIcon[trend]}
                        <span>{trendValue}</span>
                        <span className="text-[10px] opacity-80 uppercase ml-1">vs mes ant.</span>
                    </div>
                )}
            </div>
        </motion.div>
    );
};

export default KPICard;
