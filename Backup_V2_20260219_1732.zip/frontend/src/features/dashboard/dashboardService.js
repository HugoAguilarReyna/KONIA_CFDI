import api from '../../api/axiosConfig';

const dashboardService = {
    getMatrizResumen: async (filters) => {
        // Convert filters to query params
        const params = new URLSearchParams();

        // Handle period construction
        if (filters.periodo) {
            params.append('periodo', filters.periodo);
        } else if (filters.year && filters.month) {
            const m = filters.month.toString().padStart(2, '0');
            params.append('periodo', `${filters.year}-${m}`);
        }

        const response = await api.get(`/api/dashboard/matriz-resumen?${params.toString()}`);
        return response.data;
    },

    getDetalleUUID: async (periodo, page = 1, limit = 25, filters = {}) => {
        const params = new URLSearchParams();
        params.append('periodo', periodo);
        params.append('page', page);
        params.append('limit', limit);

        if (filters.flujo) params.append('flujo', filters.flujo);
        if (filters.segmento) params.append('segmento', filters.segmento);

        const response = await api.get(`/api/dashboard/detalle-uuid?${params.toString()}`);
        return response.data;
    },

    getTrazabilidad: async (filters = {}) => {
        // Support both specific UUID and general query
        if (filters.uuid) {
            const response = await api.get(`/api/dashboard/trazabilidad/${filters.uuid}`);
            return response.data;
        } else {
            const params = new URLSearchParams();
            if (filters.fecha_desde) params.append('fecha_desde', filters.fecha_desde);
            if (filters.fecha_hasta) params.append('fecha_hasta', filters.fecha_hasta);

            const response = await api.get(`/api/dashboard/trazabilidad?${params.toString()}`);
            return response.data;
        }
    },

    getDimTiempo: async (periodo) => {
        const response = await api.get(`/api/dashboard/dim-tiempo/${periodo}`);
        return response.data;
    },

    getRiskAnalysis: async (uuid) => {
        const response = await api.get(`/api/dashboard/riesgos/${uuid}`);
        return response.data;
    }
};

export default dashboardService;
