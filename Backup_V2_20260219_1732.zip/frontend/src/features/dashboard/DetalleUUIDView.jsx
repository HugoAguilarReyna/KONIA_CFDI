import React, { useEffect, useState, useMemo } from 'react';
import { Search, Download, Circle, Activity, DollarSign, Calculator, Percent, ArrowLeft, ArrowRight } from 'lucide-react';
import useFilterStore from '../../stores/useFilterStore';
import dashboardService from './dashboardService';
import KPICard from '../../components/ui/KPICard';
import DataTable from '../../components/ui/DataTable';
import { createColumnHelper } from '@tanstack/react-table';
import { Link } from 'react-router-dom';

const DetalleUUIDView = () => {
    const { filters } = useFilterStore();
    const [data, setData] = useState({ data: [], kpis: null, total_pages: 1 });
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [page, setPage] = useState(1);
    const [localFilters, setLocalFilters] = useState({ flow: 'TODOS', segment: 'TODOS' });

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                // Get period from store (format construction handled in service or passed if string)
                let periodo = filters.periodo;
                if (!periodo && filters.year && filters.month) {
                    periodo = `${filters.year}-${filters.month.toString().padStart(2, '0')}`;
                }

                const result = await dashboardService.getDetalleUUID(
                    periodo,
                    page,
                    25,
                    {
                        flujo: localFilters.flow !== 'TODOS' ? localFilters.flow : null,
                        segmento: localFilters.segment !== 'TODOS' ? localFilters.segment : null
                    }
                );
                setData(result);
            } catch (error) {
                console.error("Error fetching detail data:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [filters.year, filters.month, page, localFilters]);

    // --- KPIs ---
    const kpis = data.kpis || { total_uuids: 0, saldo_total: 0, promedio_saldo: 0, ratio_emit_recib: 0 };

    // --- Table Filtering (Client side search for current page only - ideal would be server search) ---
    // For now we rely on backend pagination, so search might only filter visible. 
    // If search is required, we should pass it to backend. The prompt didn't specify backend search.
    // We'll keep client side filter for visible items or remove if confusing. 
    // "Buscar UUID, RFC..." input exists. Let's keep client filter on the fetched page for simplicity unless requested.

    const filteredDetails = useMemo(() => {
        if (!searchTerm) return data.data || [];
        const lowerSearch = searchTerm.toLowerCase();
        return (data.data || []).filter(item =>
            item.uuid.toLowerCase().includes(lowerSearch) ||
            (item.rfc_emisor && item.rfc_emisor.toLowerCase().includes(lowerSearch)) ||
            (item.rfc_receptor && item.rfc_receptor.toLowerCase().includes(lowerSearch))
        );
    }, [data.data, searchTerm]);

    // --- Table Config ---
    const columnHelper = createColumnHelper();
    const columns = useMemo(() => [
        columnHelper.accessor('uuid', {
            header: 'UUID',
            cell: info => (
                <Link to={`/trazabilidad/${info.getValue()}`} className="font-mono text-[10px] text-indigo-600 hover:text-indigo-800 hover:underline block truncate max-w-[120px]" title={info.getValue()}>
                    {info.getValue()}
                </Link>
            ),
            size: 150
        }),
        columnHelper.accessor('periodo', {
            header: 'PERIODO',
            cell: info => <span className="text-slate-500 text-[10px]">{info.getValue()}</span>,
            size: 80
        }),
        columnHelper.accessor('flujo', {
            header: 'FLUJO',
            cell: info => (
                <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase ${info.getValue() === 'EMITIDOS' ? 'bg-indigo-50 text-indigo-700' : 'bg-orange-50 text-orange-700'}`}>
                    {info.getValue()}
                </span>
            ),
            size: 100
        }),
        columnHelper.accessor('segmento', {
            header: 'SEGMENTO',
            cell: info => <span className="text-[10px] font-bold text-slate-600">{info.getValue()}</span>,
            size: 80
        }),
        columnHelper.accessor('saldo_acumulado', {
            header: 'SALDO ACUM.',
            cell: info => <span className="font-mono font-bold text-slate-800 text-[11px] text-right block">${parseFloat(info.getValue() || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}</span>,
            size: 120
        })
    ], []);

    const handleExport = () => {
        alert("Exportando registros en formato Excel...");
    };

    return (
        <div className="space-y-8 pb-10">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 pb-6">
                <div className="space-y-2">
                    <div className="flex items-center gap-2">
                        <span className="flex items-center gap-1.5 bg-green-50 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-green-200">
                            <Circle size={8} className="fill-current animate-pulse" />
                            LIVE
                        </span>
                        <h1 className="text-xl font-bold font-mono text-slate-800 tracking-tight uppercase">EXPLORADOR DE REGISTROS UUID</h1>
                    </div>
                    <p className="text-slate-500 text-xs">Gestión detallada de folios fiscales y auditoría documental.</p>
                </div>

                <div className="flex items-center gap-3">
                    <div className="relative">
                        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input
                            type="text"
                            placeholder="Buscar UUID, RFC..."
                            className="bg-white border border-slate-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all w-64 uppercase font-mono"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <button
                        onClick={handleExport}
                        className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-bold transition-colors shadow-sm"
                    >
                        <Download size={16} />
                        EXPORTAR
                    </button>
                </div>
            </div>

            {/* KPI Cards Row (4 cols) */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <KPICard
                    title="TOTAL UUIDS"
                    value={kpis.total_uuids?.toLocaleString() || '0'}
                    icon={Activity}
                    color="primary"
                    variant="simple"
                    isLoading={loading}
                />
                <KPICard
                    title="SALDO TOTAL"
                    value={`$${(kpis.saldo_total || 0).toLocaleString('es-MX', { maximumFractionDigits: 0 })}`}
                    icon={DollarSign}
                    color="success"
                    variant="simple"
                    isLoading={loading}
                />
                <KPICard
                    title="PROMEDIO OP."
                    value={`$${(kpis.promedio_saldo || 0).toLocaleString('es-MX', { maximumFractionDigits: 0 })}`}
                    icon={Calculator}
                    color="info"
                    variant="simple"
                    isLoading={loading}
                />
                <KPICard
                    title="RATIO EMIT/RECIB"
                    value={`${(kpis.ratio_emit_recib || 0).toFixed(1)}%`}
                    icon={Percent}
                    color="warning"
                    variant="simple"
                    isLoading={loading}
                />
            </div>

            {/* Local Filters Row */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 grid grid-cols-1 md:grid-cols-3 gap-6 shadow-sm">
                <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-1">Segmento Operativo</label>
                    <select
                        value={localFilters.segment}
                        onChange={(e) => {
                            setLocalFilters({ ...localFilters, segment: e.target.value });
                            setPage(1);
                        }}
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold text-slate-700 focus:outline-none cursor-pointer"
                    >
                        <option value="TODOS">TODOS LOS SEGMENTOS</option>
                        <option value="PUE">PUE (CONTADO)</option>
                        <option value="PPD">PPD (PAGO DIFERIDO)</option>
                        <option value="OTROS">OTROS</option>
                    </select>
                </div>
                <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest pl-1">Flujo de Caja</label>
                    <select
                        value={localFilters.flow}
                        onChange={(e) => {
                            setLocalFilters({ ...localFilters, flow: e.target.value });
                            setPage(1);
                        }}
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold text-slate-700 focus:outline-none cursor-pointer"
                    >
                        <option value="TODOS">TODOS</option>
                        <option value="EMITIDOS">EMITIDOS</option>
                        <option value="RECIBIDOS">RECIBIDOS</option>
                    </select>
                </div>
                {/* Removed Range filter as backend doesn't support it yet */}
            </div>

            {/* Explorer Table */}
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 flex justify-between items-center">
                    <h3 className="text-xs font-bold text-slate-700 uppercase tracking-widest flex items-center gap-2">
                        <Activity size={14} className="text-indigo-600" />
                        AUDITORÍA DE DOCUMENTOS FISCALES
                    </h3>
                    <div className="flex gap-2">
                        <button
                            disabled={page === 1}
                            onClick={() => setPage(p => Math.max(1, p - 1))}
                            className="p-1 rounded hover:bg-slate-200 disabled:opacity-50"
                        >
                            <ArrowLeft size={16} />
                        </button>
                        <span className="text-xs font-mono self-center">PÁGINA {page}</span>
                        <button
                            onClick={() => setPage(p => p + 1)}
                            className="p-1 rounded hover:bg-slate-200"
                        >
                            <ArrowRight size={16} />
                        </button>
                    </div>
                </div>
                <DataTable
                    data={filteredDetails}
                    columns={columns}
                    isLoading={loading}
                    height={600}
                />
            </div>
        </div>
    );
};

export default DetalleUUIDView;
