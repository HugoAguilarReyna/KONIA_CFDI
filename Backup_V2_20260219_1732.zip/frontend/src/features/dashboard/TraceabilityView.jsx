import React, { useEffect, useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, FileText, Activity, DollarSign, Calendar, Search, Download, Layers } from 'lucide-react';
import dashboardService from './dashboardService';
import KPICard from '../../components/ui/KPICard';
import ChartWrapper from '../../components/ui/ChartWrapper';
import DataTable from '../../components/ui/DataTable';
import { createColumnHelper } from '@tanstack/react-table';

const TraceabilityView = () => {
    const { uuid } = useParams();
    const navigate = useNavigate();
    const [data, setData] = useState({ data: [], uuid_raiz: null }); // Response structure from backend: { data: [...], uuid_raiz: ... }
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [searchTerm, setSearchTerm] = useState(uuid || '');

    useEffect(() => {
        if (uuid) {
            setSearchTerm(uuid);
            fetchData(uuid);
        }
    }, [uuid]);

    const fetchData = async (targetUuid) => {
        setLoading(true);
        setError(null);
        try {
            // Fetch specific UUID trace
            const result = await dashboardService.getTrazabilidad({ uuid: targetUuid });
            // Result is { data: [...], uuid_raiz: ... }
            if (!result || !result.data || result.data.length === 0) {
                setError("No se encontraron registros de trazabilidad para este UUID.");
                setData({ data: [], uuid_raiz: targetUuid });
            } else {
                setData(result);
            }
        } catch (err) {
            console.error(err);
            setError("Error al consultar la trazabilidad. Verifique el UUID.");
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = (e) => {
        e.preventDefault();
        if (searchTerm) {
            navigate(`/trazabilidad/${searchTerm}`);
        }
    };

    // --- KPIs ---
    const events = data.data || [];
    const kpis = useMemo(() => {
        if (events.length === 0) return { total: 0, sum: 0, avg: 0, max: 0 };
        const amounts = events.map(e => e.monto || 0);
        const sum = amounts.reduce((a, b) => a + b, 0);
        return {
            total: events.length,
            sum: sum,
            avg: sum / events.length,
            max: Math.max(...amounts)
        };
    }, [events]);

    // --- Chart Data (Scatter Evolution) ---
    const scatterData = useMemo(() => {
        if (events.length === 0) return [];
        // X: Fecha, Y: Monto
        return [{
            x: events.map(e => e.fecha),
            y: events.map(e => e.monto),
            mode: 'lines+markers',
            type: 'scatter',
            name: 'Evolución Saldo',
            line: { shape: 'spline', color: '#6366f1', width: 3 },
            marker: { size: 8, color: '#4338ca' },
            fill: 'tozeroy',
            fillcolor: 'rgba(99, 102, 241, 0.1)'
        }];
    }, [events]);

    // --- Table Config ---
    const columnHelper = createColumnHelper();
    const columns = useMemo(() => [
        columnHelper.accessor('fecha', {
            header: 'FECHA',
            cell: info => <span className="text-slate-600 font-mono text-xs">{new Date(info.getValue()).toLocaleDateString()} {new Date(info.getValue()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>,
            size: 140
        }),
        columnHelper.accessor('concepto', {
            header: 'CONCEPTO / MOVIMIENTO',
            cell: info => <span className="font-bold text-slate-700 text-xs uppercase">{info.getValue()}</span>,
            size: 250
        }),
        columnHelper.accessor('tipo_relacion', {
            header: 'TIPO RELACIÓN',
            cell: info => <span className="text-xs text-slate-500 italic">{info.getValue()}</span>,
            size: 150
        }),
        columnHelper.accessor('uuid_relacionado', {
            header: 'UUID RELACIONADO',
            cell: info => (
                <span className="font-mono text-[10px] text-indigo-600 truncate block max-w-[150px]" title={info.getValue()}>
                    {info.getValue()}
                </span>
            ),
            size: 180
        }),
        columnHelper.accessor('monto', {
            header: 'MONTO OB.',
            cell: info => <span className="font-mono font-bold text-slate-800 text-xs text-right block">${parseFloat(info.getValue()).toLocaleString('es-MX', { minimumFractionDigits: 2 })}</span>,
            size: 120
        }),
    ], []);


    // --- View State: SEARCH (No UUID) ---
    if (!uuid) {
        return (
            <div className="max-w-4xl mx-auto space-y-8 pt-10">
                <div className="text-center space-y-4">
                    <div className="inline-flex items-center justify-center p-3 bg-indigo-100 rounded-full mb-2">
                        <Activity size={32} className="text-indigo-600" />
                    </div>
                    <h1 className="text-3xl font-bold font-mono uppercase text-slate-800 tracking-tight">TRAZABILIDAD DE FACTURAS</h1>
                    <p className="text-slate-500 text-base max-w-lg mx-auto">
                        Visualice la genealogía completa, pagos, y notas de crédito asociadas a cualquier folio fiscal.
                    </p>
                </div>

                <div className="bg-white border border-slate-200 rounded-xl shadow-lg p-8 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
                    <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4">
                        <div className="flex-1 relative">
                            <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                            <input
                                type="text"
                                placeholder="Ingrese el UUID Raíz para rastrear..."
                                className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-12 pr-4 py-4 text-base focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-mono uppercase"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-lg font-bold flex items-center justify-center gap-2 transition-colors shadow-md text-sm uppercase tracking-wide">
                            <FileText size={20} />
                            RASTREAR
                        </button>
                    </form>
                    <div className="mt-6 flex flex-wrap gap-2 justify-center">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Ejemplos recientes:</span>
                        {/* Mock examples if we had them, or just placeholders */}
                        <button onClick={() => navigate('/trazabilidad/abc-123')} className="text-[10px] bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded text-slate-600 font-mono transition-colors">abc-123...</button>
                    </div>
                </div>
            </div>
        );
    }

    // --- View State: LOADING / ERROR ---
    if (loading) return <div className="p-20 text-center text-slate-500 font-mono text-sm animate-pulse">CARGANDO MAPA DE TRAZABILIDAD...</div>;

    if (error) return (
        <div className="p-8 text-center max-w-2xl mx-auto mt-10 bg-white border border-red-100 rounded-xl shadow-sm">
            <div className="text-red-500 mb-4 flex justify-center"><Activity size={48} className="opacity-50" /></div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">No se encontró información</h3>
            <p className="text-slate-500 mb-6">{error}</p>
            <button onClick={() => navigate('/trazabilidad')} className="text-indigo-600 hover:text-indigo-800 font-bold text-sm flex items-center justify-center gap-2 mx-auto">
                <ArrowLeft size={16} /> REGRESAR AL BUSCADOR
            </button>
        </div>
    );

    // --- View State: RESULTS ---
    return (
        <div className="space-y-8 pb-10">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-4">
                <div className="flex items-center gap-4">
                    <button onClick={() => navigate('/trazabilidad')} className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors">
                        <ArrowLeft size={20} />
                    </button>
                    <div>
                        <h1 className="text-xl font-bold font-mono text-slate-800 tracking-tight uppercase">TRAZABILIDAD DE UUID</h1>
                        <span className="text-xs font-mono text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">{uuid}</span>
                    </div>
                </div>
                <button
                    onClick={() => alert("Descargando reporte de trazabilidad...")}
                    className="flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-lg text-sm font-bold transition-colors shadow-sm"
                >
                    <Download size={16} />
                    REPORTE
                </button>
            </div>

            {/* KPI Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <KPICard
                    title="EVENTOS REGISTRADOS"
                    value={kpis.total}
                    icon={Layers}
                    color="primary"
                    variant="simple"
                />
                <KPICard
                    title="MONTO ACUMULADO"
                    value={`$${kpis.sum.toLocaleString('es-MX', { maximumFractionDigits: 0 })}`}
                    icon={DollarSign}
                    color="success"
                    variant="simple"
                />
                <KPICard
                    title="PROMEDIO MOV."
                    value={`$${kpis.avg.toLocaleString('es-MX', { maximumFractionDigits: 0 })}`}
                    icon={Activity}
                    color="info"
                    variant="simple"
                />
                <KPICard
                    title="MOVIMIENTO MÁXIMO"
                    value={`$${kpis.max.toLocaleString('es-MX', { maximumFractionDigits: 0 })}`}
                    icon={Calendar} // Using Calendar as placeholder or TrendingUp
                    color="warning"
                    variant="simple"
                />
            </div>

            {/* Scatter Plot */}
            <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
                <h3 className="font-bold text-slate-700 text-sm uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">
                    EVOLUCIÓN DEL SALDO / MOVIMIENTOS
                </h3>
                <ChartWrapper
                    type="plotly"
                    data={scatterData}
                    isLoading={loading}
                    layout={{
                        margin: { t: 20, b: 40, l: 60, r: 20 },
                        height: 350,
                        xaxis: { title: 'Fecha de Movimiento' },
                        yaxis: { title: 'Monto ($)', tickprefix: '$' },
                        hovermode: 'closest'
                    }}
                />
            </div>

            {/* Events Table */}
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                <div className="bg-slate-50 px-6 py-3 border-b border-slate-200">
                    <h3 className="text-xs font-bold text-slate-700 uppercase tracking-widest flex items-center gap-2">
                        <FileText size={14} className="text-indigo-600" />
                        BITÁCORA DE EVENTOS
                    </h3>
                </div>
                <DataTable
                    data={events}
                    columns={columns}
                    isLoading={loading}
                    height={500}
                />
            </div>
        </div>
    );
};

export default TraceabilityView;
