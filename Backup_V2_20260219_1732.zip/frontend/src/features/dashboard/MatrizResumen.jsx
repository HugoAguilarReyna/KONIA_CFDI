import React, { useEffect, useState, useMemo } from 'react';
import { DollarSign, TrendingUp, TrendingDown, Activity, PieChart, CreditCard, Users, Briefcase, Copy, Check, BarChart3, AlertCircle } from 'lucide-react';
import useFilterStore from '../../stores/useFilterStore';
import dashboardService from './dashboardService';
import KPICard from '../../components/ui/KPICard';
import ChartWrapper from '../../components/ui/ChartWrapper';

const MatrizResumen = () => {
    const { filters } = useFilterStore();
    const [data, setData] = useState(null);
    const [evolution, setEvolution] = useState([]);
    const [loading, setLoading] = useState(true);
    const [copied, setCopied] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                // Parallel fetch for current period and evolution
                const [resMatriz, resEvolucion] = await Promise.all([
                    dashboardService.getMatrizResumen({
                        year: filters.year,
                        month: filters.month
                    }),
                    // Fetch evolution (last 5 periods)
                    fetch(`http://localhost:8000/api/dashboard/matriz-resumen/grafica-evolucion?periodos=5`, {
                        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
                    }).then(r => r.ok ? r.json() : [])
                ]);

                setData(resMatriz);
                setEvolution(resEvolucion);
            } catch (error) {
                console.error("Error fetching matriz data:", error);
            } finally {
                setLoading(false);
            }
        };

        if (filters.year && filters.month) {
            fetchData();
        }
    }, [filters.year, filters.month]);

    const handleCopyTable = () => {
        const table = document.getElementById('matriz-table');
        if (table) {
            const range = document.createRange();
            range.selectNode(table);
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
            document.execCommand('copy');
            window.getSelection().removeAllRanges();
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    // --- Chart Configurations & Data Processing ---
    const chartContent = useMemo(() => {
        if (!data) return null;
        const { kpis: apiKpis, matriz } = data;

        // 1. Donut: PUE = Green (#10b981), PPD = Orange (#f59e0b)
        const totalPPD = Math.abs(matriz.PPD?.["1. (+) Total Facturado"] || 0);
        const totalPUE = Math.abs(matriz.PUE?.["1. (+) Total Facturado"] || 0);
        const totalBoth = totalPPD + totalPUE;

        const donutData = [{
            type: "pie",
            hole: 0.6,
            values: [totalPUE, totalPPD],
            labels: ["PUE", "PPD"],
            marker: {
                colors: ["#10b981", "#f59e0b"],
                line: { color: "#ffffff", width: 2 }
            },
            textinfo: "percent",
            textposition: "inside",
            textfont: { color: "#ffffff", size: 13, family: "Inter" },
            hovertemplate: "<b>%{label}</b><br>$%{value:,.2f}<br>%{percent}<extra></extra>",
            showlegend: true
        }];

        const donutLayout = {
            showlegend: true,
            legend: { orientation: "h", x: 0.5, xanchor: "center", y: -0.15, font: { size: 12, family: "Inter" } },
            margin: { t: 10, b: 40, l: 10, r: 10 },
            paper_bgcolor: "rgba(0,0,0,0)",
            plot_bgcolor: "rgba(0,0,0,0)",
            annotations: [{
                text: totalBoth > 0
                    ? (totalPPD > totalPUE ? `PPD<br>${(totalPPD / totalBoth * 100).toFixed(1)}%` : `PUE<br>${(totalPUE / totalBoth * 100).toFixed(1)}%`)
                    : "NO DATA",
                x: 0.5, y: 0.5,
                font: { size: 14, family: "JetBrains Mono", color: "#374151" },
                showarrow: false
            }]
        };

        // 2. Bar PPD (Top Concepts)
        const EXCLUIR = ["1. (+) Total Facturado", "9. (=) Saldo Insoluto PPD"];
        const conceptosPPD = Object.entries(matriz.PPD || {})
            .filter(([k, v]) => !EXCLUIR.includes(k) && v !== 0)
            .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
            .slice(0, 8);

        const barPPDData = [{
            type: "bar",
            orientation: "h",
            x: conceptosPPD.map(([, v]) => Math.abs(v)),
            y: conceptosPPD.map(([k]) => k.length > 22 ? k.substring(0, 22) + '...' : k),
            marker: {
                color: "#f59e0b",
                line: { width: 0 }
            },
            hovertemplate: "<b>%{y}</b><br>$%{x:,.2f}<extra></extra>",
            text: conceptosPPD.map(([, v]) => `$${(Math.abs(v) / 1000000).toFixed(1)}M`),
            textposition: "outside",
            textfont: { size: 10, color: "#6b7280" }
        }];

        const barLayout = {
            xaxis: { tickformat: "$,.0f", showgrid: true, gridcolor: "#f1f5f9", zeroline: true, zerolinecolor: "#e2e8f0" },
            yaxis: { autorange: "reversed", tickfont: { size: 11, family: "Inter" } },
            margin: { t: 10, b: 30, l: 160, r: 60 },
            paper_bgcolor: "rgba(0,0,0,0)",
            plot_bgcolor: "rgba(0,0,0,0)",
            bargap: 0.4
        };

        // 3. Bar PUE (Top Concepts)
        const EXCLUIR_PUE = ["1. (+) Total Facturado", "9. (=) Saldo Teórico PUE"];
        const conceptosPUE = Object.entries(matriz.PUE || {})
            .filter(([k, v]) => !EXCLUIR_PUE.includes(k) && v !== 0)
            .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
            .slice(0, 8);

        const barPUEData = [{
            type: "bar",
            orientation: "h",
            x: conceptosPUE.map(([, v]) => Math.abs(v)),
            y: conceptosPUE.map(([k]) => k.length > 22 ? k.substring(0, 22) + '...' : k),
            marker: {
                color: "#10b981",
                line: { width: 0 }
            },
            hovertemplate: "<b>%{y}</b><br>$%{x:,.2f}<extra></extra>",
            text: conceptosPUE.map(([, v]) => `$${(Math.abs(v) / 1000000).toFixed(1)}M`),
            textposition: "outside",
            textfont: { size: 10, color: "#6b7280" }
        }];

        // 4. Evolution
        const evolutionData = [
            {
                type: "bar", name: "PUE",
                x: evolution.map(e => e.periodo),
                y: evolution.map(e => e.saldo_pue),
                marker: { color: "#10b981" },
                hovertemplate: "PUE %{x}<br>$%{y:,.2f}<extra></extra>"
            },
            {
                type: "bar", name: "PPD",
                x: evolution.map(e => e.periodo),
                y: evolution.map(e => e.saldo_ppd),
                marker: { color: "#f59e0b" },
                hovertemplate: "PPD %{x}<br>$%{y:,.2f}<extra></extra>"
            }
        ];

        const evolutionLayout = {
            barmode: "group",
            xaxis: { type: "category", tickfont: { size: 11, family: "JetBrains Mono" } },
            yaxis: { tickformat: "$,.1s", showgrid: true, gridcolor: "#f1f5f9", zeroline: true, zerolinecolor: "#e2e8f0", zerolinewidth: 2 },
            legend: { orientation: "h", x: 0.5, xanchor: "center", y: -0.2 },
            margin: { t: 10, b: 60, l: 70, r: 20 },
            paper_bgcolor: "rgba(0,0,0,0)",
            plot_bgcolor: "rgba(0,0,0,0)",
            bargap: 0.3,
            height: 350
        };

        const config = { responsive: true, displayModeBar: false, locale: "es" };

        return {
            donutData, donutLayout,
            barPPDData, barLayout,
            barPUEData,
            evolutionData, evolutionLayout,
            config
        };
    }, [data, evolution]);

    // --- Table Rows Logic ---
    const tableRows = useMemo(() => {
        if (!data) return [];
        const { matriz } = data;
        const rows = [];
        const CONCEPTOS_ORDEN = [
            "1. (+) Total Facturado",
            "2. (-) Notas de Crédito (01)",
            "3. (+) Nota de Débito (02)",
            "4. (-) Devoluciones (03)",
            "5. (-) Sustituciones (04)",
            "6. Traslado de mercancia (05,06)",
            "7. (-) Anticipo (07)",
            "8. (-) Pagos Aplicados (08/09)",
        ];
        const CONCEPTO_9 = { "PPD": "9. (=) Saldo Insoluto PPD", "PUE": "9. (=) Saldo Teórico PUE" };

        ["PPD", "PUE"].forEach(segmento => {
            const segData = matriz[segmento] || {};
            const totalFacturado = segData["1. (+) Total Facturado"] || 0;

            CONCEPTOS_ORDEN.forEach((concepto, idx) => {
                const monto = segData[concepto] || 0;
                rows.push({
                    type: 'item',
                    segmento: idx === 0 ? segmento : "",
                    concepto: concepto,
                    monto: monto,
                    porcentaje: totalFacturado ? `${(monto / totalFacturado * 100).toFixed(1)}%` : "0.0%",
                    status: "",
                    totalGlobal: monto,
                    isConcept1: concepto.includes("1.")
                });
            });

            const c9Name = CONCEPTO_9[segmento];
            const saldo = segData[c9Name] || 0;
            rows.push({ type: 'item', concepto: c9Name, monto: saldo, porcentaje: totalFacturado ? `${(saldo / totalFacturado * 100).toFixed(1)}%` : "0.0%", status: "OK", totalGlobal: saldo, isConcept9: true });
            rows.push({ type: 'subtotal', label: `SUBTOTAL ${segmento}`, monto: saldo, totalGlobal: saldo });
        });
        return rows;
    }, [data]);

    const formatCurrency = (val) => new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(val);

    const ChartContainer = ({ title, children, colorClass = "border-slate-200", isLoading }) => (
        <div className={`bg-white border rounded-xl shadow-sm p-5 flex flex-col h-[380px] ${colorClass} border-l-4`}>
            <h3 className="font-bold text-slate-500 text-xs uppercase tracking-wider mb-4 font-mono">{title}</h3>
            <div className="flex-1 min-h-0 relative">
                {isLoading ? (
                    <div className="absolute inset-0 animate-pulse bg-slate-100 rounded-lg flex items-center justify-center">
                        <BarChart3 className="text-slate-300 animate-bounce" size={40} />
                    </div>
                ) : children}
            </div>
        </div>
    );

    const EmptyState = ({ message = "Sin datos para este período" }) => (
        <div className="flex flex-col items-center justify-center h-full text-slate-400 gap-2">
            <AlertCircle size={32} />
            <span className="text-xs font-medium uppercase font-mono">{message}</span>
        </div>
    );

    return (
        <div className="space-y-6 pb-12">
            {/* Header */}
            <div className="flex flex-col gap-1 border-b border-slate-200 pb-4">
                <h1 className="text-xl font-bold font-mono text-slate-800 tracking-tight uppercase">MATRIZ FISCAL RESUMEN</h1>
                <div className="w-16 h-1 bg-indigo-600 rounded-full"></div>
            </div>

            {/* KPI Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
                <KPICard title="INGRESOS TOTALES" value={formatCurrency(data?.kpis?.ingresos_totales || 0)} icon={DollarSign} color="success" variant="simple" isLoading={loading} />
                <KPICard title="SALDO PPD" value={formatCurrency(data?.kpis?.saldo_ppd || 0)} subtext="Pendiente" icon={Briefcase} color="warning" variant="simple" isLoading={loading} />
                <KPICard title="INGRESO PUE" value={formatCurrency(data?.kpis?.ingreso_pue || 0)} subtext="Cobrado" icon={CreditCard} color="success" variant="simple" isLoading={loading} />
                <KPICard title="CRÉDITOS/NC" value={formatCurrency(data?.kpis?.creditos_nc || 0)} icon={TrendingDown} color="danger" variant="simple" isLoading={loading} />
                <KPICard title="RATIO PPD/PUE" value={`${(data?.kpis?.ratio_ppd_pue || 0).toFixed(1)}%`} icon={PieChart} color="info" variant="simple" isLoading={loading} />
                <KPICard title="STATUS FISCAL" value={data?.kpis?.status || "PENDIENTE"} icon={Activity} color={data?.kpis?.status === 'SALUDABLE' ? 'success' : 'danger'} variant="simple" isLoading={loading} />
            </div>

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <ChartContainer title="DISTRIBUCIÓN PPD VS PUE" colorClass="border-l-[#f59e0b]" isLoading={loading}>
                    {chartContent?.donutData ? <ChartWrapper type="plotly" data={chartContent.donutData} layout={chartContent.donutLayout} config={chartContent.config} /> : <EmptyState />}
                </ChartContainer>
                <ChartContainer title="DESGLOSE PPD (TOP CONCEPTOS)" colorClass="border-l-[#f59e0b]" isLoading={loading}>
                    {chartContent?.barPPDData?.[0]?.x?.length > 0 ? <ChartWrapper type="plotly" data={chartContent.barPPDData} layout={chartContent.barLayout} config={chartContent.config} /> : <EmptyState />}
                </ChartContainer>
                <ChartContainer title="DESGLOSE PUE (TOP CONCEPTOS)" colorClass="border-l-[#10b981]" isLoading={loading}>
                    {chartContent?.barPUEData?.[0]?.x?.length > 0 ? <ChartWrapper type="plotly" data={chartContent.barPUEData} layout={chartContent.barLayout} config={chartContent.config} /> : <EmptyState />}
                </ChartContainer>
            </div>

            {/* Evolution Chart */}
            <div className="bg-white border rounded-xl shadow-sm p-6 border-l-4 border-l-[#667eea]">
                <h3 className="font-bold text-slate-500 text-xs uppercase tracking-wider mb-6 font-mono">EVOLUCIÓN DE SALDOS (HISTÓRICO)</h3>
                <div className="h-[350px]">
                    {loading ? (
                        <div className="w-full h-full animate-pulse bg-slate-50 rounded-lg flex items-center justify-center">
                            <TrendingUp className="text-slate-200" size={48} />
                        </div>
                    ) : (
                        evolution.length > 0 ? (
                            <ChartWrapper type="plotly" data={chartContent.evolutionData} layout={chartContent.evolutionLayout} config={chartContent.config} />
                        ) : <EmptyState message="Sin historial disponible" />
                    )}
                </div>
            </div>

            {/* Matrix Table */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="p-4 flex justify-between items-center bg-[#5b6ec4]">
                    <h2 className="text-sm font-bold text-white uppercase tracking-widest font-mono">MATRIZ FINANCIERA DETALLADA</h2>
                    <button onClick={handleCopyTable} className="px-3 py-1 flex items-center gap-1.5 text-white/90 text-xs font-bold rounded-full hover:bg-white/20 transition-all border border-white/20">
                        {copied ? <Check size={14} /> : <Copy size={14} />}
                        {copied ? "COPIADO" : "COPIAR TABLA"}
                    </button>
                </div>
                <div className="overflow-x-auto">
                    <table id="matriz-table" className="w-full min-w-[900px]">
                        <thead>
                            <tr className="bg-[#5b6ec4] text-white">
                                <th className="px-4 py-3 text-left text-[10px] font-bold uppercase w-24">SEGMENTO</th>
                                <th className="px-4 py-3 text-left text-[10px] font-bold uppercase">CONCEPTO FISCAL</th>
                                <th className="px-4 py-3 text-right text-[10px] font-bold uppercase w-36">MONTO {filters.year}-{String(filters.month).padStart(2, '0')}</th>
                                <th className="px-4 py-3 text-right text-[10px] font-bold uppercase w-24">% TOTAL</th>
                                <th className="px-4 py-3 text-center text-[10px] font-bold uppercase w-20">VAR.</th>
                                <th className="px-4 py-3 text-center text-[10px] font-bold uppercase w-20">STATUS</th>
                                <th className="px-4 py-3 text-right text-[10px] font-bold uppercase w-36">TOTAL GLOBAL</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white">
                            {tableRows.map((row, idx) => {
                                if (row.type === 'subtotal') {
                                    return (
                                        <tr key={idx} className="bg-indigo-50/50 border-y-2 border-indigo-100">
                                            <td className="px-4 py-3 text-[10px] font-bold text-slate-800 uppercase">{row.label}</td>
                                            <td colSpan={5} className="px-4 py-3 text-right text-xs font-bold text-slate-700 font-mono italic">RESULTADO OPERATIVO</td>
                                            <td className="px-4 py-3 text-right text-xs font-bold text-indigo-600 font-mono">{formatCurrency(row.monto)}</td>
                                        </tr>
                                    );
                                }
                                return (
                                    <tr key={idx} className={`hover:bg-slate-50 transition-colors border-b border-slate-100 ${row.isConcept9 ? 'bg-amber-50/20' : ''}`}>
                                        <td className="px-4 py-3">
                                            {row.segmento === 'PPD' && <span className="bg-[#f59e0b]/10 text-[#f59e0b] px-2 py-0.5 rounded text-[9px] font-black tracking-tighter uppercase border border-[#f59e0b]/20">PPD</span>}
                                            {row.segmento === 'PUE' && <span className="bg-[#10b981]/10 text-[#10b981] px-2 py-0.5 rounded text-[9px] font-black tracking-tighter uppercase border border-[#10b981]/20">PUE</span>}
                                        </td>
                                        <td className={`px-4 py-3 text-xs ${row.isConcept9 ? 'font-bold text-indigo-900' : 'text-slate-600 font-medium'}`}>{row.concepto}</td>
                                        <td className={`px-4 py-3 text-xs text-right font-mono font-bold ${row.monto < 0 ? 'text-red-500' : (row.monto === 0 ? 'text-slate-200' : 'text-slate-700')}`}>{formatCurrency(row.monto)}</td>
                                        <td className="px-4 py-3 text-[10px] text-slate-500 text-right font-mono">{row.porcentaje}</td>
                                        <td className="px-4 py-3 text-[10px] text-slate-300 text-center font-mono">--</td>
                                        <td className="px-4 py-3 text-center">
                                            {row.status === 'OK' && <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-100/50 text-emerald-700 uppercase border border-emerald-200">OK</span>}
                                        </td>
                                        <td className={`px-4 py-3 text-xs text-right font-mono font-bold ${row.totalGlobal < 0 ? 'text-red-600' : 'text-emerald-700'}`}>{formatCurrency(row.totalGlobal)}</td>
                                    </tr>
                                );
                            })}
                        </tbody>
                        <tfoot>
                            <tr className="bg-[#1e293b] text-white">
                                <td colSpan={2} className="px-4 py-5 text-xs font-black uppercase tracking-widest italic font-mono">TOTAL GENERAL FISCAL (MATRIZ)</td>
                                <td className="px-4 py-5 text-right text-sm font-black font-mono border-l border-white/10">
                                    {data ? formatCurrency(data.total_general) : '$0.00'}
                                </td>
                                <td colSpan={3}></td>
                                <td className="px-4 py-5 text-right text-sm font-black font-mono underline decoration-indigo-500 decoration-4 underline-offset-8">
                                    {data ? formatCurrency(data.total_general) : '$0.00'}
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default MatrizResumen;
