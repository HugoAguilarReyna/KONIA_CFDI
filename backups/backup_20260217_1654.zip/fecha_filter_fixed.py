"""
FILTRO DE FECHA CORREGIDO
Solo usa componentes de Streamlit, sin HTML que rompa el layout
"""

import streamlit as st
from datetime import datetime

def filtro_fecha_con_calendario(
    label: str = "Período Fiscal",
    year_min: int = 2020,
    year_max: int = 2026,
):
    """
    Filtro de fecha CORRECTO para sidebar.
    
    Retorna:
    - Dict con 'year' y 'month'
    """
    
    # Inicializar estado
    if "filter_year" not in st.session_state:
        st.session_state.filter_year = datetime.now().year
    if "filter_month" not in st.session_state:
        st.session_state.filter_month = datetime.now().month
    
    # Título
    st.write(f"📅 **{label}**")
    
    # Dos columnas para Año y Mes
    col1, col2 = st.columns(2)
    
    with col1:
        year = st.selectbox(
            "Año",
            options=list(range(year_min, year_max + 1)),
            index=list(range(year_min, year_max + 1)).index(st.session_state.filter_year),
            key="year_select_key",
            label_visibility="collapsed"
        )
        st.session_state.filter_year = year
    
    with col2:
        months = [
            "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
        ]
        month_num = st.selectbox(
            "Mes",
            options=list(range(1, 13)),
            format_func=lambda x: months[x - 1],
            index=st.session_state.filter_month - 1,
            key="month_select_key",
            label_visibility="collapsed"
        )
        st.session_state.filter_month = month_num
    
    # Mostrar período seleccionado (simple, sin HTML)
    st.caption(f"✓ Período: {months[month_num - 1]} {year}")
    
    return {
        "year": st.session_state.filter_year,
        "month": st.session_state.filter_month,
    }
