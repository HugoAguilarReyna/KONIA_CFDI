import React, { useEffect, useState, useMemo } from 'react';
import { Search, Download, Filter, Activity, FileText, DollarSign, Calculator, PieChart as PieChartIcon } from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, LabelList } from 'recharts';
import useFilterStore from '../../stores/useFilterStore';
import dashboardService from './dashboardService';
import KPICard from '../../components/ui/KPICard';
import ChartCard from '../../components/ui/ChartCard';

const DetalleUUIDView = () => {
    const { filters } = useFilterStore();
    const [data, setData] = useState({
        registros: [],
        kpis: { total_uuids: 0, saldo_total: 0, promedio_saldo: 0, ratio_emit_recib: 0 },
        distribucion: {},
        top10: [],
        total: 0
    });
    const [loading, setLoading] = useState(true);
    const [searchUUID, setSearchUUID] = useState('');

    const [filtros, setFiltros] = useState({
        segmento: null,
        flujo: null,
        saldo_min: 0,
        page: 1,
        limit: 25
    });

    const nombreMes = filters.month ? new Date(2026, filters.month - 1).toLocaleString('es-MX', { month: 'long' }) : 'Mes';
    const anio = filters.year || 'Año';

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                let periodo = filters.periodo;
                if (!periodo && filters.year && filters.month) {
                    periodo = `${filters.year}-${filters.month.toString().padStart(2, '0')}`;
                }

                const result = await dashboardService.getDetalleUUID(
                    periodo,
                    filtros.page,
                    filtros.limit,
                    {
                        flujo: filtros.flujo,
                        segmento: filtros.segmento,
                        saldo_min: filtros.saldo_min,
                        uuid_search: searchUUID
                    }
                );

                setData({
                    registros: result.registros || [],
                    kpis: result.kpis || { total_uuids: 0, saldo_total: 0, promedio_saldo: 0, ratio_emit_recib: 0 },
                    distribucion: result.distribucion || {},
                    top10: result.top10 || [],
                    total: result.total || 0
                });
            } catch (error) {
                console.error("Error fetching detail data:", error);
            } finally {
                setLoading(false);
            }
        };

        const debounceTimeout = setTimeout(() => {
            fetchData();
        }, 300);

        return () => clearTimeout(debounceTimeout);
    }, [filters.year, filters.month, filtros, searchUUID]);

    const formatMoney = (amount, compact = false) => {
        if (compact && amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
        if (compact && amount >= 1000) return `$${(amount / 1000).toFixed(1)}k`;
        return new Intl.NumberFormat('es-MX', {
            style: 'currency',
            currency: 'MXN',
            maximumFractionDigits: 2
        }).format(amount);
    };

    const handleExportCSV = () => {
        const headers = [
            "UUID", "SEGMENTO", "FLUJO",
            "1. (+) Total Facturado",
            "2. (-) Notas de Crédito (01)",
            "4. (-) Devoluciones (03)",
            "7. (-) Anticipo (07)",
            "8. (-) Pagos Aplicados (08/09)",
            "9. (=) Saldo Acumulado"
        ];
        const rows = data.registros.map(doc => [
            doc.uuid,
            doc.segmento,
            doc.flujo,
            doc.conceptos?.["1. (+) Total Facturado"] ?? 0,
            doc.conceptos?.["2. (-) Notas de Crédito (01)"] ?? 0,
            doc.conceptos?.["4. (-) Devoluciones (03)"] ?? 0,
            doc.conceptos?.["7. (-) Anticipo (07)"] ?? 0,
            doc.conceptos?.["8. (-) Pagos Aplicados (08/09)"] ?? 0,
            doc.saldo_acumulado
        ]);
        const csv = [headers, ...rows]
            .map(r => r.join(","))
            .join("\n");
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `detalle_uuid_${filters.periodo || ''}.csv`;
        a.click();
        URL.revokeObjectURL(url);
    };

    const kpis = data.kpis;
    const dist = data.distribucion;
    const top10 = data.top10;
    const registros = data.registros;
    const total = data.total;
    const totalUUIDs = kpis.total_uuids || 1;

    // Colores para distribucion
    const chartData = [
        { name: "PUE", value: dist.PUE || 0, color: "#6B84F3" },
        { name: "PPD", value: dist.PPD || 0, color: "#785799" },
        { name: "OTROS", value: dist.OTROS || 0, color: "#CBD0DA" }
    ].filter(d => d.value > 0);

    return (
        <div style={{ paddingBottom: "40px" }}>
            {/* Header */}
            <div style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
                marginBottom: "24px",
                padding: "20px 24px",
                background: "white",
                borderRadius: "16px",
                borderLeft: "4px solid #6B84F3",
                boxShadow: "0 1px 3px rgba(0,0,0,0.06)"
            }}>
                {/* Izquierda */}
                <div>
                    <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "6px" }}>
                        <span style={{
                            background: "#26A69A",
                            color: "white",
                            fontSize: "9px",
                            fontFamily: "Montserrat",
                            fontWeight: 800,
                            padding: "2px 8px",
                            borderRadius: "20px",
                            letterSpacing: "0.1em"
                        }}>● LIVE</span>
                        <h2 style={{
                            fontSize: "20px",
                            fontFamily: "Montserrat",
                            fontWeight: 800,
                            color: "#1e293b",
                            letterSpacing: "0.05em",
                            textTransform: "uppercase",
                            margin: 0
                        }}>
                            Explorador de Registros UUID
                        </h2>
                    </div>
                    <p style={{
                        fontSize: "13px",
                        fontFamily: "Montserrat",
                        color: "#94a3b8",
                        fontWeight: 400,
                        margin: 0
                    }}>
                        Gestión detallada de folios fiscales y auditoría documental
                        — Período: <strong style={{ color: "#6B84F3", textTransform: 'capitalize' }}>
                            {nombreMes} {anio}
                        </strong>
                    </p>
                </div>

                {/* Derecha: Buscar + Exportar */}
                <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
                    <div style={{
                        display: "flex", alignItems: "center", gap: "8px",
                        background: "#f8fafc",
                        border: "1px solid #e2e8f0",
                        borderRadius: "10px",
                        padding: "8px 14px",
                        width: "260px"
                    }}>
                        <Search size={15} color="#94a3b8" />
                        <input
                            placeholder="Buscar UUID, RFC..."
                            value={searchUUID}
                            onChange={e => setSearchUUID(e.target.value)}
                            style={{
                                border: "none", background: "transparent",
                                fontFamily: "Montserrat", fontSize: "13px",
                                color: "#1e293b", outline: "none", width: "100%"
                            }}
                        />
                    </div>
                    <button
                        onClick={handleExportCSV}
                        style={{
                            display: "flex", alignItems: "center", gap: "8px",
                            background: "#6B84F3", color: "white",
                            border: "none", borderRadius: "10px",
                            padding: "9px 18px", cursor: "pointer",
                            fontFamily: "Montserrat", fontSize: "13px",
                            fontWeight: 700
                        }}
                    >
                        <Download size={15} />
                        EXPORTAR
                    </button>
                </div>
            </div>

            {/* KPI Cards */}
            <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(4, 1fr)",
                gap: "16px",
                marginBottom: "24px"
            }}>
                <KPICard
                    title="Total UUIDs"
                    value={kpis.total_uuids.toLocaleString("es-MX")}
                    icon={FileText}
                    accentColor="#6B84F3"
                    isLoading={loading}
                />
                <KPICard
                    title="Saldo Total"
                    value={formatMoney(kpis.saldo_total, true)}
                    icon={DollarSign}
                    accentColor="#26A69A"
                    isLoading={loading}
                />
                <KPICard
                    title="Promedio Op."
                    value={formatMoney(kpis.promedio_saldo, true)}
                    icon={Calculator}
                    accentColor="#FF8A65"
                    isLoading={loading}
                />
                <KPICard
                    title="Ratio Emit/Recib"
                    value={`${kpis.ratio_emit_recib.toFixed(1)}%`}
                    icon={PieChartIcon}
                    accentColor="#785799"
                    isLoading={loading}
                />
            </div>

            {/* Fila Filtros + Graficas */}
            <div style={{
                display: "grid",
                gridTemplateColumns: "260px 1fr 1fr",
                gap: "16px",
                marginBottom: "24px"
            }}>
                {/* Panel filtros */}
                <div style={{
                    background: "white",
                    borderRadius: "16px",
                    padding: "20px",
                    boxShadow: "0 1px 3px rgba(0,0,0,0.06)"
                }}>
                    <p style={{
                        fontSize: "14px", fontFamily: "Montserrat",
                        fontWeight: 700, color: "#1e293b",
                        marginBottom: "20px",
                        display: "flex", alignItems: "center", gap: "8px",
                        margin: "0 0 20px 0"
                    }}>
                        <Filter size={15} color="#6B84F3" />
                        Filtros de Negocio
                    </p>

                    <label style={{
                        display: "block", fontSize: "10px", fontFamily: "Montserrat",
                        fontWeight: 700, color: "#94a3b8",
                        letterSpacing: "0.08em", textTransform: "uppercase"
                    }}>
                        Segmento Operativo
                    </label>
                    <select
                        value={filtros.segmento || ""}
                        onChange={e => setFiltros(p => ({
                            ...p, segmento: e.target.value || null, page: 1
                        }))}
                        style={{
                            width: "100%", marginTop: "6px", marginBottom: "16px",
                            padding: "9px 12px", borderRadius: "8px",
                            border: "1px solid #e2e8f0",
                            fontFamily: "Montserrat", fontSize: "13px",
                            color: "#1e293b", background: "white", cursor: "pointer",
                            outline: "none"
                        }}
                    >
                        <option value="">Todos los Segmentos</option>
                        <option value="PUE">PUE</option>
                        <option value="PPD">PPD</option>
                        <option value="OTROS">OTROS</option>
                    </select>

                    <label style={{
                        display: "block", fontSize: "10px", fontFamily: "Montserrat",
                        fontWeight: 700, color: "#94a3b8",
                        letterSpacing: "0.08em", textTransform: "uppercase"
                    }}>
                        Flujo de Caja
                    </label>
                    <select
                        value={filtros.flujo || ""}
                        onChange={e => setFiltros(p => ({
                            ...p, flujo: e.target.value || null, page: 1
                        }))}
                        style={{
                            width: "100%", marginTop: "6px", marginBottom: "16px",
                            padding: "9px 12px", borderRadius: "8px",
                            border: "1px solid #e2e8f0",
                            fontFamily: "Montserrat", fontSize: "13px",
                            color: "#1e293b", background: "white", cursor: "pointer",
                            outline: "none"
                        }}
                    >
                        <option value="">Todos</option>
                        <option value="EMITIDOS">EMITIDOS</option>
                        <option value="RECIBIDOS">RECIBIDOS</option>
                    </select>

                    <label style={{
                        display: "block", fontSize: "10px", fontFamily: "Montserrat",
                        fontWeight: 700, color: "#94a3b8",
                        letterSpacing: "0.08em", textTransform: "uppercase"
                    }}>
                        Rango de Saldo Mínimo
                    </label>
                    <input
                        type="range" min={0} max={500000} step={1000}
                        value={filtros.saldo_min || 0}
                        onChange={e => setFiltros(p => ({
                            ...p, saldo_min: Number(e.target.value) || null, page: 1
                        }))}
                        style={{
                            width: "100%", marginTop: "8px",
                            accentColor: "#6B84F3"
                        }}
                    />
                    <div style={{
                        display: "flex", justifyContent: "space-between",
                        marginTop: "4px"
                    }}>
                        <span style={{
                            fontSize: "10px", color: "#94a3b8",
                            fontFamily: "Montserrat"
                        }}>
                            MIN: ${(filtros.saldo_min || 0).toLocaleString("es-MX")}
                        </span>
                        <span style={{
                            fontSize: "10px", color: "#94a3b8",
                            fontFamily: "Montserrat"
                        }}>
                            MAX: 500k+
                        </span>
                    </div>
                </div>

                {/* Donut PPD/PUE/OTROS */}
                <ChartCard title="Distribución PPD / PUE"
                    borderColor="#6B84F3">
                    <ResponsiveContainer width="100%" height={230}>
                        <PieChart>
                            <Pie
                                data={chartData}
                                cx="50%" cy="50%"
                                innerRadius={65} outerRadius={95}
                                paddingAngle={3}
                                dataKey="value"
                                strokeWidth={0}
                            >
                                {chartData.map((entry, i) => (
                                    <Cell key={i} fill={entry.color} />
                                ))}
                            </Pie>
                            <Tooltip
                                formatter={(v, n) => [
                                    `${v} UUIDs (${((v / totalUUIDs) * 100).toFixed(1)}%)`,
                                    n
                                ]}
                                contentStyle={{
                                    fontFamily: "Montserrat",
                                    borderRadius: "10px",
                                    border: "1px solid #e2e8f0",
                                    fontSize: "12px"
                                }}
                            />
                            <Legend
                                iconType="circle" iconSize={10}
                                wrapperStyle={{
                                    fontFamily: "Montserrat",
                                    fontSize: "12px"
                                }}
                            />
                        </PieChart>
                    </ResponsiveContainer>
                </ChartCard>

                {/* Top 10 UUIDs */}
                <ChartCard title="Top 10 UUIDs por Saldo"
                    borderColor="#785799">
                    <ResponsiveContainer width="100%" height={230}>
                        <BarChart
                            data={top10}
                            layout="vertical"
                            margin={{ top: 0, right: 60, left: 0, bottom: 0 }}
                        >
                            <XAxis type="number" hide />
                            <YAxis
                                type="category"
                                dataKey="uuid"
                                tickFormatter={v => v ? v.substring(0, 14) + "..." : ""}
                                tick={{
                                    fontSize: 10, fontFamily: "Montserrat",
                                    fill: "#64748b"
                                }}
                                axisLine={false} tickLine={false}
                                width={120}
                            />
                            <Tooltip
                                formatter={v => [formatMoney(v), "Saldo"]}
                                contentStyle={{
                                    fontFamily: "Montserrat",
                                    borderRadius: "10px",
                                    fontSize: "12px"
                                }}
                            />
                            <Bar dataKey="saldo_acumulado"
                                radius={[0, 6, 6, 0]} maxBarSize={16}>
                                {top10.map((entry, i) => (
                                    <Cell key={i}
                                        fill={entry.segmento === "PUE" ? "#6B84F3" :
                                            entry.segmento === "PPD" ? "#785799" :
                                                "#CBD0DA"}
                                    />
                                ))}
                                <LabelList
                                    dataKey="saldo_acumulado"
                                    position="right"
                                    formatter={v => formatMoney(v, true)}
                                    style={{
                                        fontSize: "10px",
                                        fontFamily: "JetBrains Mono, monospace",
                                        fill: "#64748b"
                                    }}
                                />
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </ChartCard>
            </div>

            {/* TABLA EXPLORADOR */}
            <div style={{
                background: "white",
                borderRadius: "16px",
                overflow: "hidden",
                boxShadow: "0 1px 3px rgba(0,0,0,0.06)"
            }}>
                <div style={{
                    display: "flex", justifyContent: "space-between",
                    alignItems: "center",
                    padding: "16px 24px",
                    borderBottom: "1px solid #f1f5f9"
                }}>
                    <p style={{
                        fontSize: "13px", fontFamily: "Montserrat",
                        fontWeight: 700, color: "#1e293b",
                        display: "flex", alignItems: "center", gap: "8px",
                        margin: 0
                    }}>
                        <Activity size={15} color="#6B84F3" />
                        Auditoría de Documentos Fiscales
                    </p>
                    <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
                        <span style={{
                            fontSize: "12px", color: "#94a3b8",
                            fontFamily: "Montserrat"
                        }}>
                            {total.toLocaleString("es-MX")} registros encontrados
                        </span>
                        <select
                            value={filtros.limit}
                            onChange={e => setFiltros(p => ({
                                ...p, limit: Number(e.target.value), page: 1
                            }))}
                            style={{
                                padding: "6px 10px", borderRadius: "8px",
                                border: "1px solid #e2e8f0",
                                fontFamily: "Montserrat", fontSize: "12px",
                                color: "#1e293b", cursor: "pointer",
                                outline: "none"
                            }}
                        >
                            <option value={25}>25 por pág.</option>
                            <option value={50}>50 por pág.</option>
                            <option value={100}>100 por pág.</option>
                        </select>
                    </div>
                </div>

                <div style={{ overflowX: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                            <tr style={{ background: "#f8fafc" }}>
                                {[
                                    { label: "UUID", width: "220px" },
                                    { label: "SEGMENTO", width: "90px" },
                                    { label: "FLUJO", width: "90px" },
                                    { label: "1. (+) TOTAL\nFACTURADO", width: "120px" },
                                    { label: "2. (-) NOTAS DE\nCRÉDITO (01)", width: "120px" },
                                    { label: "4. (-)\nDEVOLUCIONES (03)", width: "110px" },
                                    { label: "7. (-)\nANTICIPO (07)", width: "100px" },
                                    { label: "8. (-) PAGOS\nAPLICADOS (08/09)", width: "130px" },
                                    { label: "9. (=) SALDO\nACUMULADO", width: "130px" }
                                ].map((col, i) => (
                                    <th key={i} style={{
                                        padding: "12px 16px",
                                        textAlign: i <= 2 ? "left" : "right",
                                        fontSize: "10px",
                                        fontFamily: "Montserrat",
                                        fontWeight: 700,
                                        color: "#64748b",
                                        letterSpacing: "0.06em",
                                        textTransform: "uppercase",
                                        whiteSpace: "pre-line",
                                        lineHeight: 1.4,
                                        borderBottom: "2px solid #e2e8f0",
                                        width: col.width,
                                        cursor: i > 2 ? "pointer" : "default"
                                    }}>
                                        {col.label}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                <tr>
                                    <td colSpan={9} style={{ padding: "40px", textAlign: "center", color: "#94a3b8", fontFamily: "Montserrat", fontSize: "12px" }}>
                                        Cargando registros...
                                    </td>
                                </tr>
                            ) : registros.length === 0 ? (
                                <tr>
                                    <td colSpan={9} style={{ padding: "40px", textAlign: "center", color: "#94a3b8", fontFamily: "Montserrat", fontSize: "12px" }}>
                                        No se encontraron registros.
                                    </td>
                                </tr>
                            ) : registros.map((doc, i) => (
                                <tr key={doc.uuid}
                                    style={{
                                        borderBottom: "1px solid #f8fafc",
                                        transition: "background 0.15s"
                                    }}
                                    onMouseEnter={e =>
                                        e.currentTarget.style.background = "#fafbff"}
                                    onMouseLeave={e =>
                                        e.currentTarget.style.background = "white"}
                                >
                                    <td style={{ padding: "14px 16px" }}>
                                        <div style={{
                                            display: "flex",
                                            alignItems: "center", gap: "8px"
                                        }}>
                                            <div style={{
                                                width: "7px", height: "7px",
                                                borderRadius: "50%", flexShrink: 0,
                                                background:
                                                    doc.segmento === "PUE" ? "#6B84F3" :
                                                        doc.segmento === "PPD" ? "#785799" :
                                                            "#CBD0DA"
                                            }} />
                                            <span style={{
                                                fontFamily: "JetBrains Mono, monospace",
                                                fontSize: "12px",
                                                color: "#1e293b"
                                            }}>
                                                {doc.uuid}
                                            </span>
                                        </div>
                                    </td>

                                    <td style={{ padding: "14px 16px" }}>
                                        <span style={{
                                            padding: "3px 10px",
                                            borderRadius: "6px",
                                            fontSize: "11px",
                                            fontFamily: "Montserrat",
                                            fontWeight: 700,
                                            background:
                                                doc.segmento === "PUE"
                                                    ? "#6B84F315" :
                                                    doc.segmento === "PPD"
                                                        ? "#78579915" :
                                                        "#CBD0DA30",
                                            color:
                                                doc.segmento === "PUE" ? "#6B84F3" :
                                                    doc.segmento === "PPD" ? "#785799" :
                                                        "#94a3b8"
                                        }}>
                                            {doc.segmento}
                                        </span>
                                    </td>

                                    <td style={{ padding: "14px 16px" }}>
                                        <span style={{
                                            fontSize: "11px",
                                            fontFamily: "Montserrat",
                                            fontWeight: 700,
                                            color: doc.flujo === "EMITIDOS"
                                                ? "#6B84F3" : "#FF8A65",
                                            letterSpacing: "0.04em"
                                        }}>
                                            {doc.flujo}
                                        </span>
                                    </td>

                                    {[
                                        doc.conceptos?.["1. (+) Total Facturado"] ?? 0,
                                        doc.conceptos?.["2. (-) Notas de Crédito (01)"] ?? 0,
                                        doc.conceptos?.["4. (-) Devoluciones (03)"] ?? 0,
                                        doc.conceptos?.["7. (-) Anticipo (07)"] ?? 0,
                                        doc.conceptos?.["8. (-) Pagos Aplicados (08/09)"] ?? 0,
                                    ].map((val, j) => (
                                        <td key={j} style={{
                                            padding: "14px 16px",
                                            textAlign: "right",
                                            fontFamily: "JetBrains Mono, monospace",
                                            fontSize: "13px",
                                            color: val === 0 ? "#cbd5e1" :
                                                j === 0 ? "#26A69A" :
                                                    j === 4 ? "#FF8A65" :
                                                        "#ef4444",
                                            fontWeight: val === 0 ? 400 : 600
                                        }}>
                                            {val === 0
                                                ? "0.00"
                                                : formatMoney(val)}
                                        </td>
                                    ))}

                                    <td style={{
                                        padding: "14px 16px",
                                        textAlign: "right",
                                        fontFamily: "JetBrains Mono, monospace",
                                        fontSize: "13px",
                                        fontWeight: 700,
                                        color: doc.saldo_acumulado > 0 ? "#26A69A" :
                                            doc.saldo_acumulado < 0 ? "#ef4444" :
                                                "#cbd5e1"
                                    }}>
                                        {formatMoney(doc.saldo_acumulado)}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div style={{
                    display: "flex", justifyContent: "space-between",
                    alignItems: "center",
                    padding: "14px 24px",
                    borderTop: "1px solid #f1f5f9"
                }}>
                    <span style={{
                        fontSize: "12px", color: "#94a3b8",
                        fontFamily: "Montserrat"
                    }}>
                        Página {filtros.page} de {Math.max(1, Math.ceil(total / filtros.limit))}
                    </span>
                    <div style={{ display: "flex", gap: "8px" }}>
                        <button
                            onClick={() => setFiltros(p =>
                                ({ ...p, page: Math.max(1, p.page - 1) }))}
                            disabled={filtros.page === 1}
                            style={{
                                padding: "6px 14px", borderRadius: "8px",
                                border: "1px solid #e2e8f0",
                                fontFamily: "Montserrat", fontSize: "12px",
                                fontWeight: 600,
                                background: filtros.page === 1 ? "#f8fafc" : "white",
                                color: filtros.page === 1 ? "#cbd5e1" : "#1e293b",
                                cursor: filtros.page === 1 ? "not-allowed" : "pointer"
                            }}
                        >
                            ← Anterior
                        </button>
                        <button
                            onClick={() => setFiltros(p =>
                                ({ ...p, page: p.page + 1 }))}
                            disabled={filtros.page >= Math.ceil(total / filtros.limit)}
                            style={{
                                padding: "6px 14px", borderRadius: "8px",
                                border: filtros.page >= Math.ceil(total / filtros.limit) ? "1px solid #e2e8f0" : "none",
                                fontFamily: "Montserrat", fontSize: "12px",
                                fontWeight: 600,
                                background: filtros.page >= Math.ceil(total / filtros.limit) ? "#f8fafc" : "#6B84F3",
                                color: filtros.page >= Math.ceil(total / filtros.limit) ? "#cbd5e1" : "white",
                                cursor: filtros.page >= Math.ceil(total / filtros.limit) ? "not-allowed" : "pointer"
                            }}
                        >
                            Siguiente →
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DetalleUUIDView;
