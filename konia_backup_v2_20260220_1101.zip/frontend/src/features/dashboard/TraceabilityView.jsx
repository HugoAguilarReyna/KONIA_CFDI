import React, { useState, useEffect } from 'react';
import {
    Download, Search, Layers, DollarSign, Calendar, Clock,
    GitBranch, FileText, CreditCard
} from 'lucide-react';
import {
    ComposedChart, Area, Scatter, XAxis, YAxis,
    CartesianGrid, Tooltip, ReferenceLine,
    ResponsiveContainer
} from 'recharts';
import useFilterStore from '../../stores/useFilterStore';
import dashboardService from './dashboardService';

const EvolucionSaldoChart = ({ data }) => {
    const CustomDot = (props) => {
        const { cx, cy, payload } = props
        const color = payload.concepto?.startsWith("1.") ? "#26A69A" :
            payload.concepto?.startsWith("8.") ? "#FF8A65" :
                "#6B84F3"
        return (
            <g>
                <circle cx={cx} cy={cy} r={6} fill="white" stroke={color} strokeWidth={2.5} />
                <circle cx={cx} cy={cy} r={3} fill={color} />
            </g>
        )
    }

    const CustomTooltip = ({ active, payload }) => {
        if (!active || !payload?.length) return null
        const d = payload[0]?.payload
        if (!d) return null
        return (
            <div style={{
                background: "#1e293b", borderRadius: "12px",
                padding: "12px 16px", boxShadow: "0 8px 24px rgba(0,0,0,0.2)",
                minWidth: "220px"
            }}>
                <p style={{ fontFamily: "JetBrains Mono", fontSize: "11px", color: "#94a3b8", marginBottom: "8px" }}>
                    {d.fecha}
                </p>
                <p style={{ fontFamily: "Montserrat", fontSize: "11px", color: "white", fontWeight: 600, marginBottom: "6px" }}>
                    {d.concepto}
                </p>
                <div style={{ display: "flex", justifyContent: "space-between", gap: "20px" }}>
                    <div>
                        <p style={{ fontSize: "9px", color: "#64748b", fontFamily: "Montserrat" }}>MONTO</p>
                        <p style={{ fontFamily: "JetBrains Mono", fontSize: "13px", fontWeight: 700, color: d.monto >= 0 ? "#26A69A" : "#FF8A65" }}>
                            {formatMoney(d.monto)}
                        </p>
                    </div>
                    <div>
                        <p style={{ fontSize: "9px", color: "#64748b", fontFamily: "Montserrat" }}>SALDO ACUM.</p>
                        <p style={{ fontFamily: "JetBrains Mono", fontSize: "13px", fontWeight: 700, color: d.saldo >= 0 ? "#6B84F3" : "#ef4444" }}>
                            {formatMoney(d.saldo)}
                        </p>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <ResponsiveContainer width="100%" height={220}>
            <ComposedChart data={data} margin={{ top: 10, right: 20, left: 80, bottom: 10 }}>
                <defs>
                    <linearGradient id="gradSaldo" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6B84F3" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#6B84F3" stopOpacity={0} />
                    </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="fecha" tick={{ fontSize: 10, fontFamily: "Montserrat", fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <YAxis tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 10, fontFamily: "JetBrains Mono", fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <ReferenceLine y={0} stroke="#26A69A" strokeWidth={1.5} strokeDasharray="6 3" label={{ value: "Liquidación", position: "insideTopRight", fontSize: 10, fontFamily: "Montserrat", fill: "#26A69A" }} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="saldo" stroke="#6B84F3" strokeWidth={2} fill="url(#gradSaldo)" dot={<CustomDot />} activeDot={{ r: 8, fill: "#6B84F3", stroke: "white", strokeWidth: 2 }} />
            </ComposedChart>
        </ResponsiveContainer>
    )
}

const KPICard = ({ title, value, icon: Icon, accentColor }) => (
    <div style={{
        background: "white", borderRadius: "16px", padding: "16px",
        display: "flex", alignItems: "center", gap: "16px",
        boxShadow: "0 1px 3px rgba(0,0,0,0.06)",
        borderBottom: `3px solid ${accentColor}`
    }}>
        <div style={{
            width: "42px", height: "42px", borderRadius: "12px",
            background: `${accentColor}15`, display: "flex",
            alignItems: "center", justifyContent: "center"
        }}>
            <Icon size={20} color={accentColor} />
        </div>
        <div>
            <p style={{ fontSize: "11px", color: "#64748b", fontFamily: "Montserrat", fontWeight: 700, letterSpacing: "0.05em", textTransform: "uppercase", marginBottom: "4px" }}>
                {title}
            </p>
            <p style={{ fontSize: "16px", fontWeight: 800, color: "#1e293b", fontFamily: "JetBrains Mono" }}>
                {value}
            </p>
        </div>
    </div>
)

const formatMoney = (amount, includeSign = false) => {
    if (amount === undefined || amount === null) return "$0.00";
    const str = new Intl.NumberFormat('en-US', {
        style: 'currency', currency: 'USD', minimumFractionDigits: 2
    }).format(Math.abs(amount));
    if (includeSign) { return amount < 0 ? `-${str}` : str; }
    return str;
};

const TraceabilityView = () => {
    const { periodo } = useFilterStore();
    const [uuidsDisponibles, setUuidsDisponibles] = useState([]);
    const [busqueda, setBusqueda] = useState('');
    const [uuidSeleccionado, setUuidSeleccionado] = useState(null);
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        loadUuids();
    }, [periodo]);

    useEffect(() => {
        if (uuidSeleccionado) {
            loadDetalleUuid(uuidSeleccionado);
        }
    }, [uuidSeleccionado]);

    const loadUuids = async () => {
        try {
            setLoading(true);
            const res = await dashboardService.getUuidsDisponibles();
            console.log("DEBUG LOAD UUIDS:", res);
            if (Array.isArray(res)) {
                setUuidsDisponibles(res);
            } else {
                setError(`Unexpected response format: ${JSON.stringify(res)}`);
            }
        } catch (error) {
            console.error("Error loading UUIDs list:", error);
            setError(`Error fetching UUIDs: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    const loadDetalleUuid = async (uuid) => {
        try {
            setLoading(true);
            setError(null);
            const res = await dashboardService.getTrazabilidad(uuid);
            console.log("DEBUG LOAD DETALLE:", res);
            setData(res);
        } catch (error) {
            console.error("Error loading UUID detail:", error);
            setError(`Error fetching detail for ${uuid}: ${error.message} ${error.response?.data?.detail || ''}`);
        } finally {
            setLoading(false);
        }
    };

    const handleSelectUUID = (uuid) => setUuidSeleccionado(uuid);

    const handleExportCSV = () => {
        if (!data || !data.eventos) return;
        const csvRows = [
            ['#', 'FECHA/HORA', 'CONCEPTO', 'TIPO RELACIÓN', 'UUID RELACIONADO', 'MONTO', 'SALDO ACUMULADO']
        ];
        data.eventos.forEach((e, i) => {
            csvRows.push([
                i + 1, e.fecha, `"${e.concepto}"`, e.tipo_relacion,
                e.uuid_relacionado || '', e.monto, e.saldo_acumulado
            ]);
        });
        const csvContent = "data:text/csv;charset=utf-8," + csvRows.map(r => r.join(',')).join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `Trazabilidad_${uuidSeleccionado || 'General'}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const uuidsFiltrados = uuidsDisponibles.filter(u => u.uuid.toLowerCase().includes(busqueda.toLowerCase()));

    return (
        <div style={{ padding: "24px", background: "#f8fafc", minHeight: "100vh" }}>
            {/* HEADER DE LA VISTA */}
            <div style={{
                display: "flex", justifyContent: "space-between", alignItems: "flex-start", padding: "20px 24px",
                background: "white", borderRadius: "16px", borderLeft: "4px solid #785799",
                boxShadow: "0 1px 3px rgba(0,0,0,0.06)", marginBottom: "24px"
            }}>
                <div>
                    <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "6px" }}>
                        <span style={{ background: "#26A69A", color: "white", fontSize: "9px", fontFamily: "Montserrat", fontWeight: 800, padding: "2px 8px", borderRadius: "20px", letterSpacing: "0.1em" }}>● LIVE</span>
                        <h2 style={{ fontSize: "20px", fontFamily: "Montserrat", fontWeight: 800, color: "#1e293b", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                            Trazabilidad de UUID Fiscal
                        </h2>
                    </div>
                    <p style={{ fontSize: "13px", fontFamily: "Montserrat", color: "#94a3b8", fontWeight: 400 }}>
                        Seguimiento cronológico de eventos y pagos por folio CFDI
                    </p>
                </div>
                <button onClick={handleExportCSV} style={{ display: "flex", alignItems: "center", gap: "8px", background: "#785799", color: "white", border: "none", borderRadius: "10px", padding: "9px 18px", cursor: "pointer", fontFamily: "Montserrat", fontSize: "13px", fontWeight: 700 }}>
                    <Download size={15} /> EXPORTAR TRAZA
                </button>
            </div>

            {/* LAYOUT PRINCIPAL CON GRID */}
            <div style={{ display: "grid", gridTemplateColumns: "300px 1fr", gap: "16px" }}>

                {/* PANEL SELECTOR DE UUID */}
                <div style={{ background: "white", borderRadius: "16px", boxShadow: "0 1px 3px rgba(0,0,0,0.06)", display: "flex", flexDirection: "column", height: "calc(100vh - 280px)", minHeight: "500px" }}>
                    <div style={{ padding: "16px 16px 12px" }}>
                        <p style={{ fontSize: "11px", fontFamily: "Montserrat", fontWeight: 700, color: "#94a3b8", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: "10px" }}>Seleccionar UUID</p>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px", background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "10px", padding: "8px 12px" }}>
                            <Search size={14} color="#94a3b8" />
                            <input placeholder="Buscar UUID..." value={busqueda} onChange={e => setBusqueda(e.target.value)} style={{ border: "none", background: "transparent", fontFamily: "Montserrat", fontSize: "12px", color: "#1e293b", outline: "none", width: "100%" }} />
                        </div>
                    </div>
                    <div style={{ padding: "0 16px 10px", fontSize: "10px", color: "#94a3b8", fontFamily: "Montserrat" }}>
                        {uuidsFiltrados.length} UUIDs disponibles
                    </div>
                    <div style={{ overflowY: "auto", flex: 1, borderTop: "1px solid #f1f5f9" }}>
                        {uuidsFiltrados.map(u => (
                            <div key={u.uuid} onClick={() => handleSelectUUID(u.uuid)} style={{ padding: "12px 16px", cursor: "pointer", background: uuidSeleccionado === u.uuid ? "#6B84F308" : "transparent", borderLeft: uuidSeleccionado === u.uuid ? "3px solid #785799" : "3px solid transparent", borderBottom: "1px solid #f8fafc", transition: "all 0.15s" }}>
                                <p style={{ fontFamily: "JetBrains Mono", fontSize: "11px", color: uuidSeleccionado === u.uuid ? "#785799" : "#475569", fontWeight: uuidSeleccionado === u.uuid ? 700 : 400, marginBottom: "6px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                    {u.uuid}
                                </p>
                                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                    <span style={{ padding: "2px 8px", borderRadius: "20px", fontSize: "9px", fontFamily: "Montserrat", fontWeight: 800, letterSpacing: "0.06em", background: u.estado === "LIQUIDADO" ? "#26A69A15" : u.estado === "INSOLUTO" ? "#FF8A6515" : "#ef444415", color: u.estado === "LIQUIDADO" ? "#26A69A" : u.estado === "INSOLUTO" ? "#FF8A65" : "#ef4444" }}>
                                        {u.estado === "LIQUIDADO" ? "✓ LIQUIDADO" : u.estado === "INSOLUTO" ? "● INSOLUTO" : "✕ NEG"}
                                    </span>
                                    <span style={{ fontFamily: "JetBrains Mono", fontSize: "11px", fontWeight: 700, color: u.ultimo_saldo === 0 ? "#26A69A" : u.ultimo_saldo > 0 ? "#FF8A65" : "#ef4444" }}>
                                        {formatMoney(u.ultimo_saldo, true)}
                                    </span>
                                </div>
                                <div style={{ display: "flex", justifyContent: "space-between", marginTop: "4px" }}>
                                    <span style={{ fontSize: "9px", color: "#94a3b8", fontFamily: "Montserrat" }}>{u.total_eventos} eventos</span>
                                    <span style={{ fontSize: "9px", color: "#94a3b8", fontFamily: "JetBrains Mono" }}>{u.ultimo_evento}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* COLUMNA DERECHA */}
                <div>
                    {!uuidSeleccionado || !data ? (
                        /* ESTADO INICIAL */
                        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "400px", gap: "16px", background: "white", borderRadius: "16px", boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
                            <div style={{ width: "64px", height: "64px", borderRadius: "20px", background: "#78579915", display: "flex", alignItems: "center", justifyContent: "center" }}>
                                <GitBranch size={32} color="#785799" />
                            </div>
                            <p style={{ fontFamily: "Montserrat", fontSize: "16px", fontWeight: 700, color: "#1e293b" }}>Selecciona un UUID</p>
                            <p style={{ fontFamily: "Montserrat", fontSize: "13px", color: "#94a3b8", textAlign: "center", maxWidth: "300px" }}>Elige un folio fiscal del panel izquierdo para ver su trazabilidad completa de eventos</p>
                            {error && (
                                <div style={{ marginTop: "20px", padding: "12px", background: "#fee2e2", color: "#ef4444", borderRadius: "8px", fontFamily: "JetBrains Mono", fontSize: "11px", maxWidth: "80%" }}>
                                    {error}
                                </div>
                            )}
                        </div>
                    ) : (
                        <>
                            {/* KPI CARDS */}
                            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px", marginBottom: "16px" }}>
                                <KPICard title="Total Eventos" value={data.kpis.total_eventos.toLocaleString()} icon={Layers} accentColor="#6B84F3" />
                                <KPICard title="Saldo Final" value={formatMoney(data.kpis.saldo_final, true)} icon={DollarSign} accentColor={data.kpis.estado === "LIQUIDADO" ? "#26A69A" : data.kpis.estado === "INSOLUTO" ? "#FF8A65" : "#ef4444"} />
                                <KPICard title="Primer Evento" value={data.kpis.primer_evento} icon={Calendar} accentColor="#FFCA28" />
                                <KPICard title="Último Evento" value={data.kpis.ultimo_evento} icon={Clock} accentColor="#785799" />
                            </div>

                            {/* BARRA DE PROGRESO DE LIQUIDACIÓN */}
                            {data.kpis.monto_original > 0 && (
                                <div style={{ background: "white", borderRadius: "16px", padding: "16px 20px", marginBottom: "16px", boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
                                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "10px" }}>
                                        <span style={{ fontSize: "11px", fontFamily: "Montserrat", fontWeight: 700, color: "#64748b", letterSpacing: "0.06em", textTransform: "uppercase" }}>Progreso de Liquidación</span>
                                        <span style={{ fontSize: "13px", fontFamily: "JetBrains Mono", fontWeight: 700, color: data.kpis.pct_liquidado >= 100 ? "#26A69A" : data.kpis.pct_liquidado >= 50 ? "#FFCA28" : "#FF8A65" }}>{Math.min(data.kpis.pct_liquidado, 100).toFixed(1)}% liquidado</span>
                                    </div>
                                    <div style={{ background: "#f1f5f9", borderRadius: "20px", height: "10px", overflow: "hidden" }}>
                                        <div style={{ height: "100%", width: `${Math.min(data.kpis.pct_liquidado, 100)}%`, borderRadius: "20px", background: data.kpis.pct_liquidado >= 100 ? "linear-gradient(90deg, #26A69A, #00BCD4)" : data.kpis.pct_liquidado >= 50 ? "linear-gradient(90deg, #FFCA28, #FF8A65)" : "linear-gradient(90deg, #FF8A65, #ef4444)", transition: "width 0.6s ease" }} />
                                    </div>
                                    <div style={{ display: "flex", justifyContent: "space-between", marginTop: "8px" }}>
                                        <span style={{ fontSize: "11px", color: "#94a3b8", fontFamily: "JetBrains Mono" }}>Original: {formatMoney(data.kpis.monto_original)}</span>
                                        <span style={{ fontSize: "11px", color: "#94a3b8", fontFamily: "JetBrains Mono" }}>Pagado: {formatMoney(data.kpis.total_pagado)}</span>
                                        <span style={{ fontSize: "11px", fontFamily: "JetBrains Mono", color: data.kpis.saldo_final > 0 ? "#FF8A65" : "#26A69A", fontWeight: 700 }}>Saldo: {formatMoney(data.kpis.saldo_final)}</span>
                                    </div>
                                </div>
                            )}

                            {/* GRÁFICA EVOLUCIÓN DEL SALDO */}
                            <div style={{ background: "white", borderRadius: "16px", padding: "20px", marginBottom: "16px", boxShadow: "0 1px 3px rgba(0,0,0,0.06)", borderTop: `4px solid #6B84F3` }}>
                                <h3 style={{ fontSize: "12px", fontFamily: "Montserrat", fontWeight: 700, color: "#1e293b", letterSpacing: "0.05em", marginBottom: "16px" }}>EVOLUCIÓN DEL SALDO ACUMULADO</h3>
                                <EvolucionSaldoChart data={data.evolucion_saldo} />
                            </div>

                            {/* TABLA HISTORIAL DE EVENTOS */}
                            <div style={{ background: "white", borderRadius: "16px", overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
                                <div style={{ padding: "16px 24px", borderBottom: "1px solid #f1f5f9", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                    <p style={{ fontSize: "13px", fontFamily: "Montserrat", fontWeight: 700, color: "#1e293b", display: "flex", alignItems: "center", gap: "8px" }}>
                                        <GitBranch size={15} color="#785799" /> Historial de Eventos
                                        <span style={{ background: "#78579915", color: "#785799", borderRadius: "20px", padding: "2px 10px", fontSize: "10px", fontWeight: 800 }}>{data.eventos.length} registros</span>
                                    </p>
                                </div>
                                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                    <thead>
                                        <tr style={{ background: "#f8fafc" }}>
                                            {[{ label: "#", w: "40px", align: "center" }, { label: "FECHA / HORA", w: "140px", align: "left" }, { label: "CONCEPTO", w: "auto", align: "left" }, { label: "TIPO RELACIÓN", w: "120px", align: "center" }, { label: "UUID RELACIONADO", w: "200px", align: "left" }, { label: "MONTO", w: "140px", align: "right" }, { label: "SALDO ACUMULADO", w: "150px", align: "right" }].map((col, i) => (
                                                <th key={i} style={{ padding: "12px 16px", textAlign: col.align, fontSize: "10px", fontFamily: "Montserrat", fontWeight: 700, color: "#64748b", letterSpacing: "0.06em", textTransform: "uppercase", borderBottom: "2px solid #e2e8f0", width: col.w }}>{col.label}</th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {data.eventos.map((evento, i) => {
                                            const esPago = evento.tipo_relacion === "PAGO";
                                            const esFactura = evento.concepto?.startsWith("1.");
                                            const saldoCero = Math.abs(evento.saldo_acumulado) < 0.01;
                                            return (
                                                <tr key={i} style={{ borderBottom: "1px solid #f8fafc", background: saldoCero ? "#26A69A08" : esPago ? "#FF8A6505" : "white", transition: "background 0.15s" }} onMouseEnter={e => e.currentTarget.style.background = "#f8faff"} onMouseLeave={e => e.currentTarget.style.background = saldoCero ? "#26A69A08" : esPago ? "#FF8A6505" : "white"}>
                                                    <td style={{ padding: "14px 16px", textAlign: "center", fontFamily: "JetBrains Mono", fontSize: "11px", color: "#94a3b8" }}>{i + 1}</td>
                                                    <td style={{ padding: "14px 16px" }}><span style={{ fontFamily: "JetBrains Mono", fontSize: "12px", color: "#475569" }}>{evento.fecha}</span></td>
                                                    <td style={{ padding: "14px 16px" }}>
                                                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                                                            <div style={{ width: "28px", height: "28px", borderRadius: "8px", background: esFactura ? "#26A69A15" : esPago ? "#FF8A6515" : "#6B84F315", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                                                                {esFactura ? <FileText size={13} color="#26A69A" /> : <CreditCard size={13} color="#FF8A65" />}
                                                            </div>
                                                            <span style={{ fontFamily: "Montserrat", fontSize: "12px", color: "#1e293b", fontWeight: esFactura ? 600 : 400 }}>{evento.concepto}</span>
                                                        </div>
                                                    </td>
                                                    <td style={{ padding: "14px 16px", textAlign: "center" }}>
                                                        <span style={{ padding: "3px 12px", borderRadius: "20px", fontSize: "10px", fontFamily: "Montserrat", fontWeight: 800, letterSpacing: "0.06em", background: evento.tipo_relacion === "PAGO" ? "#FF8A6515" : "#6B84F315", color: evento.tipo_relacion === "PAGO" ? "#FF8A65" : "#6B84F3" }}>{evento.tipo_relacion}</span>
                                                    </td>
                                                    <td style={{ padding: "14px 16px" }}>
                                                        {evento.uuid_relacionado ? (
                                                            <span style={{ fontFamily: "JetBrains Mono", fontSize: "11px", color: "#6B84F3", cursor: "pointer", textDecoration: "underline", textDecorationStyle: "dotted" }} onClick={() => handleSelectUUID(evento.uuid_relacionado)} title="Click para ver trazabilidad">
                                                                {evento.uuid_relacionado.substring(0, 18)}...
                                                            </span>
                                                        ) : (<span style={{ color: "#cbd5e1", fontFamily: "Montserrat", fontSize: "12px" }}>—</span>)}
                                                    </td>
                                                    <td style={{ padding: "14px 16px", textAlign: "right", fontFamily: "JetBrains Mono", fontSize: "13px", fontWeight: 600, color: evento.monto > 0 ? "#26A69A" : evento.monto < 0 ? "#FF8A65" : "#cbd5e1" }}>{formatMoney(evento.monto)}</td>
                                                    <td style={{ padding: "14px 16px", textAlign: "right" }}>
                                                        <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: "8px" }}>
                                                            {saldoCero && (<span style={{ background: "#26A69A15", color: "#26A69A", fontSize: "9px", fontFamily: "Montserrat", fontWeight: 800, padding: "2px 6px", borderRadius: "20px" }}>✓ SALDADO</span>)}
                                                            <span style={{ fontFamily: "JetBrains Mono", fontSize: "13px", fontWeight: 700, color: saldoCero ? "#26A69A" : evento.saldo_acumulado > 0 ? "#6B84F3" : "#ef4444" }}>{formatMoney(evento.saldo_acumulado)}</span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            )
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default TraceabilityView;
